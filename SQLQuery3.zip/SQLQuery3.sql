create database enesodev2;

use enesodev2;

create table tablo (
	Uye_Ad� varchar(255),
	Uye_Soyad� varchar(255),
	Cinsiyet int,
	Adres_No int,
);

INSERT INTO tablo (Uye_Ad�, Uye_Soyad�, Cinsiyet, Adres_No)
VALUES ('Ali', 'Y�ld�z', 0, 1),
       ('Ay�e', 'Y�lmaz', 1, 2),
	   ('Ahmet', 'Kareli', 0, 3),
	   ('Nilay', 'Kaya', 1, 4),
       ('Eray', 'De�er', 0, 5);

SELECT * FROM tablo;
